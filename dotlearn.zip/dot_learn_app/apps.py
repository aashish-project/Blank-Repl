from django.apps import AppConfig


class DotLearnAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "dot_learn_app"
